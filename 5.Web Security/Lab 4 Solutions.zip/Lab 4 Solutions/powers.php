<!-- compute powers of a number -->
<html>
<title> Powers</title>
<body>
<h4>Powers of a number</h4>

<!-- a compentent HTLM coder would frown at my
	use of &nbsp, but it's simple...
-->

<?php
$tab = "&nbsp &nbsp &nbsp &nbsp";
echo "n" . $tab . "n^2" . $tab . "n^3" . "<br>";
$x = 1;
echo $x . $tab . $x*$x . $tab . $x*$x*$x . "<br>";
$x = 2;
echo $x . $tab . $x*$x . $tab . $x*$x*$x . "<br>";
$x = 3;
echo $x . $tab . $x*$x . $tab . $x*$x*$x . "<br>";
?>

</body></html>