<!-- compute powers of a number -->
<html>
<title> Powers</title>
<body>
<h4>Powers of a number</h4>

<?php
echo "n" . "&nbsp" . "n^2" . "&nbsp" . "n^3" . "<br>";
$x = 1;
echo $x . "&nbsp".  $x*$x . "&nbsp". $x*$x*$x . "<br>";
$x = 2;
echo $x . "&nbsp".  $x*$x . "&nbsp". $x*$x*$x . "<br>";
$x = 3;
echo $x . "&nbsp".  $x*$x . "&nbsp". $x*$x*$x . "<br>";
?>
</body></html>

