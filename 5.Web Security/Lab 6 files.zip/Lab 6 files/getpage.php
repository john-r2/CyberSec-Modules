<?php
include($_GET['Page']);
?>